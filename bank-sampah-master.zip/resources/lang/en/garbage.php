<?php

return [
    'success' => [
        'create' => 'Garbage created successfully',
        'update' => 'Garbage updated successfully',
        'delete' => 'Garbage deleted successfully',
    ],
];
