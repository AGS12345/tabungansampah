<li class="nav-item has-treeview <?php echo e(request()->is($actives) ? 'menu-open' : ''); ?>">
    <a href="#" class="nav-link <?php echo e(request()->is($actives) ? 'active' : ''); ?>">
        <i class="nav-icon fas <?php echo e($icon ?? 'fa-circle'); ?>"></i>
        <p>
            <?php echo e($text); ?>

            <i class="right fa fa-angle-left"></i>
        </p>
    </a>
    <ul class="nav nav-treeview">
        <?php echo e($slot); ?>

    </ul>
</li>
