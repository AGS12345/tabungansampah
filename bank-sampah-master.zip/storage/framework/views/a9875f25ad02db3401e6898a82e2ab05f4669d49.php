<?php $str = app('Illuminate\Support\Str'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php echo $__env->make('partials._alert-success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <a href="<?php echo e(route('garbage.create')); ?>" class="btn btn-primary btn-lg mb-3">
        <?php echo e(__('Add new garbage')); ?>

    </a>

    <div class="card">
        <div class="card-body table-responsive p-0">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo e(__('Name')); ?></th>
                        <th><?php echo e(__('Buy price')); ?></th>
                        <th><?php echo e(__('Sell price')); ?></th>
                        <th><?php echo e(__('Description')); ?></th>
                        <th><?php echo e(__('Action')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $garbage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $trash): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + $garbage->firstItem()); ?></td>
                            <td><?php echo e($trash->name); ?></td>
                            <td><?php echo e($trash->buy_price); ?></td>
                            <td><?php echo e($trash->sell_price); ?></td>
                            <td><?php echo e($str->words($trash->description, 10)); ?></td>
                            <td>
                                <a href="<?php echo e(route('garbage.show', $trash)); ?>" class="btn btn-sm btn-secondary mb-1">
                                    <i class="fas fa-eye mr-1"></i>
                                    <?php echo e(__('View')); ?>

                                </a>
                                <a href="<?php echo e(route('garbage.edit', $trash)); ?>" class="btn btn-sm btn-warning mb-1">
                                    <i class="fas fa-edit mr-1"></i>
                                    <?php echo e(__('Edit')); ?>

                                </a>
                                <form class="d-inline-block" action="<?php echo e(route('garbage.destroy', $trash)); ?>" method="POST"
                                    onsubmit="return confirm('Do you really want to delete that?');"
                                >
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-sm btn-danger mb-1">
                                        <i class="fas fa-trash mr-1"></i>
                                        <?php echo e(__('Delete')); ?>

                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="card-footer cleafix">
            <?php echo e($garbage->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>