<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <form action="<?php echo e(route('garbage.store')); ?>" method="POST">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title"><?php echo e(__('Add new garbage')); ?></h6>

                            <?php echo $__env->make('garbage._form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>