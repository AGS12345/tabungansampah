<li class="nav-item">
    <a href="<?php echo e($href ?? '#'); ?>" class="nav-link <?php echo e(request()->is($active ?? '') ? 'active' : ''); ?>">
        <i class="nav-icon fas <?php echo e($icon ?? 'fa-circle'); ?>"></i>
        <p><?php echo e($text); ?></p>
    </a>
</li>
