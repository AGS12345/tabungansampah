<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title"><?php echo e($garbage->name); ?></h6>

                        <dl class="row">
                            <dt class="col-sm-3"><?php echo e(__('Buy Price')); ?></dt>
                            <dd class="col-sm-9"><?php echo e($garbage->buy_price); ?></dd>

                            <dt class="col-sm-3"><?php echo e(__('Sell Price')); ?></dt>
                            <dd class="col-sm-9"><?php echo e($garbage->sell_price); ?></dd>

                            <dt class="col-sm-3"><?php echo e(__('Description')); ?></dt>
                            <dd class="col-sm-9"><?php echo e($garbage->description); ?></dd>
                        </dl>

                        <a href="<?php echo e(route('garbage.index')); ?>" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left"></i>
                            <?php echo e(__('Back')); ?>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>