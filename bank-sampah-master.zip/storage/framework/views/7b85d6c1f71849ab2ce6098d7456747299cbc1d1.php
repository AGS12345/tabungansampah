<?php echo $__env->make('partials._alert-errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo csrf_field(); ?>
<div class="form-group">
    <label for="name"><?php echo e(__('Name')); ?></label>
    <input type="text" class="form-control" id="name" name="name"
        value="<?php echo e(old('name', $garbage->name)); ?>"
    >
</div>

<div class="form-group">
    <label for="buy_price"><?php echo e(__('Buying Price')); ?></label>
    <input type="text" class="form-control" id="buy_price" name="buy_price"
        value="<?php echo e(old('buy_price', $garbage->buy_price)); ?>"
    >
</div>

<div class="form-group">
    <label for="sell_price"><?php echo e(__('Selling Price')); ?></label>
    <input type="text" class="form-control" id="sell_price" name="sell_price"
        value="<?php echo e(old('sell_price', $garbage->sell_price)); ?>"
    >
</div>

<div class="form-group">
    <label for="description"><?php echo e(__('Description')); ?></label>
    <textarea class="form-control" name="description" id="description" rows="5"
    ><?php echo e(old('description', $garbage->description)); ?></textarea>
</div>

<a href="<?php echo e(route('garbage.index')); ?>" class="btn btn-outline-secondary">
    <i class="fas fa-arrow-left"></i>
    <?php echo e(__('Back')); ?>

</a>
<button class="btn btn-primary">
    <i class="fas fa-save"></i>
    <?php echo e(__('Save')); ?>

</button>
