<nav class="mt-2">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <?php echo $__env->make('partials._nav-item', [
            'text' => 'Dashboard',
            'href' => '/home',
            'active' => 'home*',
            'icon' => 'fa-tachometer-alt',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->startComponent('nav-treeview', [
            'text' => 'Management',
            'actives' => ['garbage*', 'types*'],
            'icon' => 'fa-cog',
        ]); ?>
            <?php echo $__env->make('partials._nav-item', [
                'text' => 'Data Sampah',
                'href' => route('garbage.index'),
                'active' => 'garbage*',
                'icon' => 'fa-boxes',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('partials._nav-item', [
                'text' => 'Data Jenis Sampah',
                'href' => '#',
                'active' => 'types*',
                //'icon' => 'fa-user',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->renderComponent(); ?>

        <?php echo $__env->make('partials._nav-item', [
            'text' => 'Profile',
            'href' => '#',
            'active' => 'profile*',
            'icon' => 'fa-user',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('partials._nav-item', [
            'text' => 'Logout',
            'href' => '#',
            'icon' => 'fa-power-off',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </ul>
</nav>
